//
//  exercise1.cpp
//  CSC121
//
//  Created by Aaron Cleveland on 10/12/21.
//

#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    // Declared two integers.
    int num_one;
    int num_two;

    // Prompts user and grabs there input for first value
    cout << "Please enter a numeric value: \n";
    cin >> num_one;

    // Prompts user and grabs there input for second value.
    cout << "Please enter a numeric value: \n";
    cin >> num_two;

    // Checks if the number one is greater, less or equal to number 2.
    // Prints out the smalles value or if they are equal.
    if (num_one > num_two)
        cout << "The smallest value is " << num_two << endl;
    else if (num_one < num_two)
        cout << "The smallest value is " << num_one << endl;
    else
        cout << "They are equal" << endl;

    return 0;
}
